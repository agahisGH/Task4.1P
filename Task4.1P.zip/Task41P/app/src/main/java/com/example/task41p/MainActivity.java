package com.example.task41p;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView timer;

    TextView lastTimeTask;
    EditText enterTask;
    ImageButton playButton;
    ImageButton pauseButton;
    ImageButton stopButton;

    String TIME;
    String oldTime;
    String TASK;
    String oldTask;

    int seconds = 0;
    boolean running;
    int reloadSeconds;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timer = findViewById(R.id.textViewTimer);

        lastTimeTask = findViewById(R.id.textViewLastTime);
        enterTask = findViewById(R.id.editTextEnterTask);
        playButton = findViewById(R.id.imageButtonPlay);
        pauseButton = findViewById(R.id.imageButtonPause);
        stopButton = findViewById(R.id.imageButtonStop);

        timerStart();

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (enterTask.getText().toString().matches("")){
                    Toast.makeText(MainActivity.this, "You need to enter your task first.", Toast.LENGTH_SHORT).show();
                    return;
                }
                running = true;
            }
        });

        pauseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                running = false;
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                running = false;
                saveData();
            }
        });

        if(savedInstanceState != null){
            if(running = true){
                reloadSeconds = savedInstanceState.getInt("saveSeconds");
                //Log.i("timer", String.valueOf(reloadSeconds));
                seconds += reloadSeconds;
            }
        }

        loadData();
        lastTimeTask.setText("You spent " + oldTime + " on " + oldTask + " last time.");
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt("saveSeconds", seconds);
    }

    public void saveData(){
        SharedPreferences sharedPreferences = getSharedPreferences("com.example.task41p", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("TIME", timer.getText().toString());
        editor.putString("TASK", enterTask.getText().toString());
        editor.apply();
    }

    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences("com.example.task41p", MODE_PRIVATE);
        oldTime = sharedPreferences.getString("TIME", "");
        oldTask = sharedPreferences.getString("TASK", "");
    }

    private void timerStart() {
        //timer = findViewById(R.id.textViewTimer);
        Handler handler = new Handler();

        handler.post(new Runnable() {
            @Override
            public void run() {
                int hours = seconds / 3600;
                int minutes = (seconds % 3600) / 60;
                int secs = seconds % 60;

                String time = String.format(Locale.getDefault(),
                        "%02d:%02d:%02d",
                        hours, minutes, secs);

                timer.setText(time);

                if(running){
                    seconds++;
                }
                handler.postDelayed(this, 1000);
            }
        });
    }
}